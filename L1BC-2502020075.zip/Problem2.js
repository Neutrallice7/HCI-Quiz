// getCost 
// getPrice 
// getName

var ingredients = ['Strawberries', 'Banana', 'Mango', 'Blueberries', 'Raspberries', 'Apple', 'Pineapple'];

function smoothie(n) {
    if (ingredients[n]) {
        ingredients[n];
    }
}
